
 /*
James Roll
Expressions
Wpf 1411
11-3-2014
 */

//alert("testing 1.2,3!");

//This will gather information from the user calculate the miles driven in a week and tell them to drive safely.

var usersName = prompt("Enter your Name. (First, Last)");
var miles = prompt("Please enter how many miles you drive a day.");
var daysWeekly = prompt("Please enter how many days a week you drive.")
var milesWeekly = daysWeekly*miles;
var results = "I have news for you " +usersName+ " you will drive a total of " +milesWeekly+ " this week.\nI hope you have a great day and drive safe!"

alert(results);


